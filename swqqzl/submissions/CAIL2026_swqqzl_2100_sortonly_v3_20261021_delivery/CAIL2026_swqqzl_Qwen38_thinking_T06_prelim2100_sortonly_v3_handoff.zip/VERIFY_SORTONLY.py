#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Validate scope, real retained official warnings, native provenance, and copy-only rollback."""
import csv
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from verify_common import D, ORIGINAL_SHA, sha, strict, rows, load_module, field_diff, official_check, native_provenance


def main():
    assert len(sys.argv) == 2 and sys.argv[1] in ('baseline', 'previous_v2', 'modified', 'rollback')
    stage = sys.argv[1]
    (D / 'checks').mkdir(exist_ok=True)
    original_bytes = (D / 'original/prediction.jsonl').read_bytes()
    assert sha(original_bytes) == ORIGINAL_SHA
    rollback = None
    revised_bytes = (D / 'MODIFIED_FILE.jsonl').read_bytes()
    if stage == 'rollback':
        (D / 'rollback_test').mkdir(exist_ok=True)
        pred = D / 'rollback_test/prediction.jsonl'
        pred.write_bytes(revised_bytes)
        cmd = [str(D / 'ROLLBACK.sh'), str(pred)]
        r = subprocess.run(cmd, capture_output=True, text=True)
        assert r.returncode == 0 and pred.read_bytes() == original_bytes
        assert (D / 'MODIFIED_FILE.jsonl').read_bytes() == revised_bytes
        rollback = {'command': cmd, 'literal_stdout': r.stdout, 'literal_stderr': r.stderr, 'exit_status': r.returncode, 'restored_status': 'Original byte hash restored on separate copy; delivery still v3.'}
    else:
        pred = D / {'baseline': 'original/prediction.jsonl', 'previous_v2': 'original/REFERENCE_V2_prediction.jsonl', 'modified': 'MODIFIED_FILE.jsonl'}[stage]
    data = pred.read_bytes()
    original, predictions = rows(original_bytes), rows(data)
    inputs = rows((D / 'official/inputs.jsonl').read_bytes())
    assert len(predictions) == len(original) == len(inputs) == 2100
    assert len({p['sample_id'] for p in predictions}) == 2100
    assert [x['sample_id'] for x in inputs] == [x['sample_id'] for x in predictions]
    protocol = load_module(D / 'official/protocol.py', 'frozen_strict_protocol')
    for p in predictions:
        protocol.validate(p, p['sample_id'])
    official = official_check(pred)
    expected_warn = {'baseline': 144, 'previous_v2': 0, 'modified': 10, 'rollback': 144}[stage]
    assert official['ERROR'] == 0 and official['WARN'] == expected_warn
    result = {'stage': stage.upper(), 'status': 'PASS', 'checked_at': datetime.now(timezone.utc).isoformat(), 'input_path': str(pred), 'prediction_sha256': sha(data), 'rows': 2100, 'unique_ids': 2100, 'exact_input_order': True, 'strict_schema_rows': 2100, 'official': official, 'rollback': rollback}
    reference = list(csv.DictReader((D / 'original/OFFICIAL_WARNINGS_144.csv').open(encoding='utf-8-sig')))
    remaining = [r for r in reference if 'organized_infringement=' in r['official_warning']]
    assert len(remaining) == 10
    if stage in ('baseline', 'rollback'):
        assert data == original_bytes
        assert official['all_warnings'] == [r['official_warning'] for r in reference]
    elif stage == 'previous_v2':
        assert sha(data) == '00c90605e2004afe176349208e725e45f83ec306390bf562570b78ab508537e8'
    else:
        assert data == (D / 'prediction.jsonl').read_bytes()
        # Match the checker output verbatim, not a filtered or synthesized count.
        assert official['all_warnings'] == [r['official_warning'] for r in remaining]
        assert all('organized_infringement=' in w for w in official['all_warnings'])
        changes = rows((D / 'CHANGES_134.jsonl').read_bytes())
        by_id = {x['sample_id']: x for x in changes}
        restored = strict((D / 'RESPONSIBILITY_RESTORED_10.json').read_bytes())
        restored_ids = {r['sample_id'] for r in restored}
        assert len(changes) == len(by_id) == 134 and len(restored) == len(restored_ids) == 10
        assert restored_ids == {r['sample_id'] for r in remaining}
        labels = strict((D / 'official/labels.json').read_bytes())
        checker_module = load_module(D / 'official/check_submission.py', 'frozen_official_checker')
        previous = rows((D / 'original/REFERENCE_V2_prediction.jsonl').read_bytes())
        assert [x['sample_id'] for x in previous] == [x['sample_id'] for x in predictions]
        changed, unchanged, vs_v2 = 0, 0, 0
        for old, new, prior, query, old_line, new_line in zip(original, predictions, previous, inputs, original_bytes.splitlines(keepends=True), data.splitlines(keepends=True)):
            sid = old['sample_id']
            # The entire B block must match original on ALL rows, not just the ten flagged rows.
            assert old['prediction']['task_B'] == new['prediction']['task_B']
            assert old['prediction']['task_A'] == new['prediction']['task_A']
            assert old['prediction']['citations'] == new['prediction']['citations']
            assert old['prediction']['task_C']['disposal_measures'] == new['prediction']['task_C']['disposal_measures']
            diff = field_diff(old, new)
            if diff:
                assert diff == ['prediction.task_C.priority_order'] and sid in by_id
                c = by_id[sid]
                assert old['prediction']['task_C']['priority_order'] == c['before']
                expected = checker_module._urgency(old['prediction']['task_C']['disposal_measures'], query['context']['propagation_level'], labels['disposal_urgency_order'], labels['disposal_urgency_modifier'])
                assert new['prediction']['task_C']['priority_order'] == c['after'] == expected
                assert set(c['before']) == set(c['after'])
                assert new == prior
                changed += 1
            else:
                assert sid not in by_id and old_line == new_line
                unchanged += 1
            if sid in restored_ids:
                assert new == old and new != prior and old_line == new_line
                diff2 = field_diff(prior, new)
                assert len(diff2) == 1 and diff2[0] in ('prediction.task_B.organized_infringement', 'prediction.task_B.organizer_liability')
                vs_v2 += 1
            else:
                assert new == prior
        assert changed == 134 and unchanged == 1966 and vs_v2 == 10
        for r in restored:
            sid = r['sample_id']
            old = next(x for x in original if x['sample_id'] == sid)
            new = next(x for x in predictions if x['sample_id'] == sid)
            assert r['original_task_B'] == r['v3_task_B'] == old['prediction']['task_B'] == new['prediction']['task_B']
        with (D / 'OFFICIAL_WARNINGS_10.csv').open('w', encoding='utf-8-sig', newline='') as f:
            w = csv.writer(f)
            w.writerow(['sample_id', 'official_warning', 'handling'])
            for r in remaining:
                w.writerow([r['sample_id'], r['official_warning'], '恢复并保留原版责任判断；待实体复核，本次不为消警告改判'])
        (D / 'OFFICIAL_WARNINGS_10.txt').write_text('剩余10条WARN：全部为原版责任字段一致性警告，原样保留，不做实体改判。\n\n' + '\n'.join(official['all_warnings']) + '\n', encoding='utf-8')
        (D / 'OFFICIAL_WARNINGS_10.json').write_text(json.dumps(remaining, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        result.update({'changed_rows_vs_original': 134, 'changed_fields_vs_original': 134, 'changed_path_only': 'prediction.task_C.priority_order', 'unchanged_rows_byte_exact': 1966, 'entire_task_B_original_exact_rows': 2100, 'responsibility_cases_restored_from_v2': 10, 'only_10_responsibility_fields_differ_vs_v2': True, 'sort_fixes_identical_to_v2': 134, 'remaining_warnings_exact_original_subset': True, 'remaining_sort_warnings': 0, 'remaining_responsibility_warnings': 10, 'remaining_warning_groups': {'false_with_liability': 8, 'true_without_liability': 2}, 'native': native_provenance(original, predictions, inputs), 'revision_is_sorting_only_postprocessing': True, 'model_rerun': False, 'uploaded': False})
        # A responsibility edit is explicitly rejected by the allowed-field scope.
        bad = json.loads(json.dumps(predictions[0]))
        bad['prediction']['task_B']['organized_infringement'] = not bad['prediction']['task_B']['organized_infringement']
        assert field_diff(predictions[0], bad) == ['prediction.task_B.organized_infringement']
        assert field_diff(predictions[0], bad) != ['prediction.task_C.priority_order']
        result['negative_control_responsibility_edit'] = 'REJECTED_BY_SORT_ONLY_SCOPE'
    external = strict((D / 'original/ORIGINAL_FILES_SHA256.json').read_bytes())
    count = 0
    for path, m in external.items():
        p = Path(path)
        if p.exists():
            assert p.stat().st_size == m['bytes'] and sha(p.read_bytes()) == m['sha256'], path
            count += 1
    result['prior_original_v2_review_files_unchanged'] = count
    result['prior_files_manifest_count'] = len(external)
    if stage == 'rollback':
        assert (D / 'prediction.jsonl').read_bytes() == (D / 'MODIFIED_FILE.jsonl').read_bytes() == revised_bytes
        result['restored_behavior'] = 'Separate copy restored to original ERROR=0 WARN=144 exit=0; delivered v3 remains ERROR=0 WARN=10.'
    literal = {
        'baseline': 'BASELINE PASS rows=2100 ERROR=0 WARN=144',
        'previous_v2': 'PREVIOUS_V2 PASS rows=2100 ERROR=0 WARN=0',
        'modified': 'MODIFIED PASS rows=2100 ERROR=0 WARN=10 priority_fixed=134 responsibility_restored=10 task_B_original_exact=2100',
        'rollback': 'ROLLBACK PASS rows=2100 ERROR=0 WARN=144 original_restored=true delivered_v3_unchanged=true',
    }[stage]
    result['literal_result'] = literal
    (D / 'checks' / (stage.upper() + '.json')).write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    (D / 'checks' / (stage.upper() + '_OFFICIAL.txt')).write_text(official['literal_stdout'] + official['literal_stderr'], encoding='utf-8')
    print(literal)


if __name__ == '__main__':
    main()
