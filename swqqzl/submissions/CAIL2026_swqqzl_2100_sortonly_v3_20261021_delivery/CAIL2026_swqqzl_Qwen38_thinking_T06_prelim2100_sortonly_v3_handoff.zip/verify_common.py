#!/usr/bin/env python3
"""Reproducible, non-mutating official/schema/provenance checks of a reviewed copy."""
import contextlib
import copy
import csv
import hashlib
import importlib.util
import io
import json
import re
import runpy
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

D = Path(__file__).resolve().parent
ORIGINAL_SHA = '72929a96f039d40ec442f5d656c061817c5ac9ab485dd3f06326746626711232'
CHECKER_SHA = '2eabf603d9cdf6e422c9f0234615c4873da4b72c62634b2119a7fcc2b07f7cce'
HANDOFF_SHA = '581dda70c86a040a0cada79466868b12c50fea72eb0cd4f0b7c3e0f66b7437e9'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def strict(data):
    def unique(items):
        obj = {}
        for key, value in items:
            assert key not in obj, 'duplicate JSON key: ' + key
            obj[key] = value
        return obj
    return json.loads(data, object_pairs_hook=unique, parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def rows(data):
    assert data.endswith(b'\n')
    assert not any(not line.strip() for line in data.splitlines())
    return [strict(line) for line in data.splitlines()]


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, str(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def get(obj, path):
    for key in path.split('.'):
        obj = obj[key]
    return obj


def field_diff(old, new, prefix=''):
    if isinstance(old, dict) and isinstance(new, dict):
        assert old.keys() == new.keys(), 'unexpected field addition/removal'
        result = []
        for key in old:
            result += field_diff(old[key], new[key], prefix + ('.' if prefix else '') + key)
        return result
    return [] if type(old) == type(new) and old == new else [prefix]


def official_check(pred):
    checker = D / 'official/check_submission.py'
    assert sha(checker.read_bytes()) == CHECKER_SHA
    cmd = [sys.executable, str(checker), '--pred', str(pred), '--data', str(D / 'official/inputs.jsonl'), '--labels', str(D / 'official/labels.json')]
    result = subprocess.run(cmd, capture_output=True, text=True)
    assert result.returncode == 0, result.stdout + result.stderr
    errors = int(re.search(r'^ERROR\s*:\s*(\d+)', result.stdout, re.M).group(1))
    warns = int(re.search(r'^WARN\s*:\s*(\d+)', result.stdout, re.M).group(1))
    captured = {}
    oldargv, oldtrace = sys.argv[:], sys.gettrace()
    buf = io.StringIO()

    def trace(frame, event, arg):
        if event == 'exception' and frame.f_code.co_name == 'main' and Path(frame.f_code.co_filename).resolve() == checker and isinstance(arg[1], SystemExit):
            captured['warnings'] = list(frame.f_locals['warns'])
            captured['errors'] = list(frame.f_locals['errors'])
        return trace
    try:
        sys.argv = cmd[1:]
        sys.settrace(trace)
        with contextlib.redirect_stdout(buf):
            try:
                runpy.run_path(str(checker), run_name='__main__')
            except SystemExit as e:
                assert e.code == 0
    finally:
        sys.settrace(oldtrace)
        sys.argv = oldargv
    assert captured['errors'] == [] and len(captured['warnings']) == warns
    assert sha(checker.read_bytes()) == CHECKER_SHA
    return {'command': cmd, 'exit_status': result.returncode, 'literal_stdout': result.stdout, 'literal_stderr': result.stderr, 'ERROR': errors, 'WARN': warns, 'all_warnings': captured['warnings'], 'checker_sha256': CHECKER_SHA}


def native_provenance(original, revised, inputs):
    source = D / 'original/ORIGINAL_HANDOFF.zip'
    assert sha(source.read_bytes()) == HANDOFF_SHA
    matches, stop, thinking, attempts_count, unchanged = 0, 0, 0, 0, 0
    response_ids = set()
    with zipfile.ZipFile(source) as z:
        assert z.testzip() is None
        assert z.read('runs/full_prelim/prediction.jsonl') == (D / 'original/prediction.jsonl').read_bytes()
        assert z.read('inputs/prelim.jsonl') == (D / 'official/inputs.jsonl').read_bytes()
        assert z.read('data/raw/labels.json') == (D / 'official/labels.json').read_bytes()
        assert z.read('main_system.txt') == (D / 'official/main_system.txt').read_bytes()
        assert sha(z.read('materials/official/repository/swqqzl/选手工具/check_submission.py')) == CHECKER_SHA
        raw = rows(z.read('data/raw/prelim.jsonl'))
        assert all(r['truth'] is None and q == {k: v for k, v in r.items() if k != 'truth'} for r, q in zip(raw, inputs))
        assert len(raw) == 2100
        frozen = strict(z.read('evidence/FROZEN_SOURCES.json'))
        for path, h in frozen.items():
            assert sha(z.read(path)) == h
        cfg = strict(z.read('CONFIG.json'))
        prompt = z.read('main_system.txt').decode()
        codebook = strict(z.read('codebook.json'))
        source_paths = [n for n in z.namelist() if n.startswith('runs/full_prelim/worker') and n.endswith('.json') and not n.endswith('.attempts.json')]
        assert len(source_paths) == 2100
        by_sid = {Path(n).stem: n for n in source_paths}
        for old, new, query in zip(original, revised, inputs):
            sid = old['sample_id']
            record = strict(z.read(by_sid[sid]))
            assert record['sample_id'] == sid and record['prediction'] == old
            attempts = record['attempts']
            attempts_count += len(attempts)
            final = attempts[-1]
            response = final['response']
            choice = response['choices'][0]
            message = choice['message']
            assert final['success'] is True and response['model'] == 'Qwen/Qwen3.8-27B'
            assert response['id'] not in response_ids
            response_ids.add(response['id'])
            assert strict(message['content']) == old
            assert choice['finish_reason'] == 'stop'
            reason = message.get('reasoning') or message.get('reasoning_content')
            assert isinstance(reason, str) and reason.strip()
            for attempt in attempts:
                req = attempt['request']
                assert sha(json.dumps(req, ensure_ascii=False).encode()) == attempt['request_sha256']
                assert req['messages'][:3] == [{'role': 'system', 'content': prompt}, {'role': 'user', 'content': json.dumps({'official_schema': codebook}, ensure_ascii=False)}, {'role': 'user', 'content': json.dumps(query, ensure_ascii=False)}]
                assert req['chat_template_kwargs'] == {'enable_thinking': True, 'reasoning_effort': 'medium'}
                for k in ('model', 'temperature', 'top_p', 'top_k', 'min_p', 'presence_penalty', 'repetition_penalty', 'max_tokens', 'seed', 'reasoning_effort'):
                    assert req[k] == cfg[k]
                assert attempt['tokenize']['count'] + cfg['max_tokens'] <= cfg['context_length']
            matches += 1
            thinking += 1
            stop += 1
            unchanged += new == old
    assert matches == thinking == stop == 2100 and unchanged == 1966
    return {'original_native_JSON_matches': matches, 'original_native_nonempty_thinking': thinking, 'original_native_stop': stop, 'original_success_record_attempts': attempts_count, 'revised_still_native_equal_rows': unchanged, 'revised_postprocessed_rows': 134, 'raw_responses_edited': False, 'original_native_archive_sha256': HANDOFF_SHA}


