"""Strict output protocol; diagnostics are non-mutating and never repair predictions."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parent
LABELS = json.loads((ROOT / 'data/raw/labels.json').read_text(encoding='utf-8'))

def _enum(values):
    return {'type': 'string', 'enum': list(values)}

def _array(values):
    return {'type': 'array', 'items': _enum(values), 'uniqueItems': True}

def _object(properties):
    return {'type': 'object', 'properties': properties, 'required': list(properties), 'additionalProperties': False}

def schema(sample_id):
    if not isinstance(sample_id, str) or not sample_id:
        raise ValueError('sample_id must be nonempty string')
    l = LABELS
    nec = set(l['element_necessity']['necessary'])
    elements = {'type': 'object', 'properties': {k: _enum(l['element_values_necessary'] if k in nec else l['element_values_circumstantial']) for k in l['elements']}, 'minProperties': 1, 'additionalProperties': False}
    a = _object({'infringement_types': _array([t['code'] for t in l['infringement_types']]), 'boundary_conclusion': _enum(l['boundary_values']), 'exemptions': _array(l['exemptions']), 'element_judgments': elements, 'severity': _enum(l['severity'])})
    b = _object({'publisher_liability': _enum(l['liability']['publisher']), 'organizer_liability': _enum(l['liability']['organizer']), 'platform_obligation': _array(l['liability']['platform_obligation']), 'platform_obligation_fulfilled': {'type': 'boolean'}, 'platform_liability': _enum(l['liability']['platform_type']), 'organized_infringement': {'type': 'boolean'}})
    c = _object({'disposal_measures': _array([m['code'] for m in l['disposal_measures']]), 'priority_order': _array([m['code'] for m in l['disposal_measures']])})
    return _object({'sample_id': _enum([sample_id]), 'prediction': _object({'task_A': a, 'task_B': b, 'task_C': c, 'citations': _array(list(l['law_articles']) + list(l['case_anchors']))})})

def _check(value, spec, path):
    t = spec['type']
    ok = {'object': isinstance(value, dict), 'array': isinstance(value, list), 'string': isinstance(value, str), 'boolean': type(value) is bool}[t]
    if not ok:
        raise ValueError(f'{path}: expected {t}')
    if 'enum' in spec and value not in spec['enum']:
        raise ValueError(f'{path}: invalid enum {value!r}')
    if t == 'object':
        if set(spec.get('required', [])) - set(value):
            raise ValueError(f'{path}: missing keys')
        if spec.get('additionalProperties') is False and set(value) - set(spec['properties']):
            raise ValueError(f'{path}: unexpected keys')
        if len(value) < spec.get('minProperties', 0):
            raise ValueError(f'{path}: empty object')
        for k, v in value.items():
            _check(v, spec['properties'][k], f'{path}.{k}')
    elif t == 'array':
        for i, v in enumerate(value):
            _check(v, spec['items'], f'{path}[{i}]')
        if spec.get('uniqueItems') and len(set(value)) != len(value):
            raise ValueError(f'{path}: duplicate items')

def validate(pred, sample_id):
    """Raise ValueError for structural failures, without changing any answer."""
    _check(pred, schema(sample_id), '$')
    p = pred['prediction']; a, c = p['task_A'], p['task_C']
    if set(c['disposal_measures']) != set(c['priority_order']):
        raise ValueError('priority_order and disposal_measures sets differ')
    if a['boundary_conclusion'] in {'不构成侵权', '存疑待查'}:
        if a['infringement_types'] or c['disposal_measures'] or c['priority_order'] or a['severity'] != '不适用':
            raise ValueError('boundary empty-task/severity rule')
    elif not a['infringement_types'] or a['severity'] == '不适用':
        raise ValueError('positive boundary requires types and applicable severity')
    if c['disposal_measures'] and not p['citations']:
        raise ValueError('measures require citations')

def diagnostics(pred, row):
    """Semantic findings only. Caller must not overwrite or withhold valid predictions."""
    validate(pred, row['sample_id'])
    out = []; p = pred['prediction']; a, b, c = p['task_A'], p['task_B'], p['task_C']; l = LABELS
    nec = set(l['element_necessity']['necessary']); by_type = {t['code']: t for t in l['infringement_types']}
    for t in a['infringement_types']:
        for e in by_type[t]['elements']:
            if e in nec and a['element_judgments'].get(e) != '构成':
                out.append(f'type_required_element:{t}:{e}:{a["element_judgments"].get(e, "MISSING")}')
    if b['organized_infringement'] != (b['organizer_liability'] != '不承担责任'):
        out.append('organizer_equivalence')
    no_civil = set(l['liability']['platform_obligation'][:3]); civil = set(l['liability']['platform_obligation'][3:6]); admin = l['liability']['platform_obligation'][6]
    obligations = b['platform_obligation']; fulfilled = b['platform_obligation_fulfilled']; liable = b['platform_liability'] != '不承担责任'
    if not obligations:
        out.append('platform_obligation_empty')
    for obligation in obligations:
        if obligation in no_civil and (not fulfilled or liable): out.append(f'platform_relation:{obligation}')
        if obligation in civil and (fulfilled or not liable): out.append(f'platform_relation:{obligation}')
        if obligation == admin and (fulfilled or liable): out.append(f'platform_administrative_exception:{obligation}')
    order = l['disposal_urgency_order']; expected = sorted(c['disposal_measures'], key=order.index)
    mod = l['disposal_urgency_modifier']
    if row.get('context', {}).get(mod['field']) == mod['trigger']:
        expected = [x for x in expected if x in mod['promote']] + [x for x in expected if x not in mod['promote']]
    if c['priority_order'] != expected: out.append('priority_urgency_order')
    if c['disposal_measures'] != sorted(c['disposal_measures']): out.append('measure_code_order')
    if a['boundary_conclusion'] in {'不构成侵权', '存疑待查'} and p['citations']: out.append('boundary_nonempty_citations')
    # Membership is verified above; topical relevance remains a separate diagnostic.
    related = set()
    for t in a['infringement_types']:
        related.update(by_type[t].get('law', [])); related.update(l['type_case_anchors'].get(t, []))
    related.update({'MD1165', 'MD1026'})
    if b['organized_infringement']: related.update({'MD1169', 'MD1194'})
    if b['platform_liability'] != '不承担责任' or obligations: related.update({'MD1194', 'MD1195', 'MD1196', 'MD1197', 'WB10', 'WB15', 'ZL16'})
    for citation in p['citations']:
        if citation not in related: out.append(f'citation_relevance_needs_review:{citation}')
    return out
