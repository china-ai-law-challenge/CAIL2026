#!/bin/sh
# Restore only a disposable rollback_test copy; never overwrite the delivered revision.
set -eu
D=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec python3 - "$D" "${1:-$D/rollback_test/prediction.jsonl}" <<'PY'
import hashlib, sys
from pathlib import Path
d = Path(sys.argv[1]).resolve()
t = Path(sys.argv[2]).resolve()
assert (d / 'rollback_test').resolve() in t.parents, 'target must be inside rollback_test/'
assert t.name == 'prediction.jsonl' and t.is_file(), 'expected an existing disposable prediction copy'
before = (d / 'original/prediction.jsonl').read_bytes()
modified = (d / 'MODIFIED_FILE.jsonl').read_bytes()
assert t.read_bytes() == modified, 'rollback test target must match the revised version'
assert hashlib.sha256(before).hexdigest() == '72929a96f039d40ec442f5d656c061817c5ac9ab485dd3f06326746626711232'
t.write_bytes(before)
assert t.read_bytes() == before
assert (d / 'MODIFIED_FILE.jsonl').read_bytes() == modified
print('ROLLBACK_RESTORE PASS original_sha256=' + hashlib.sha256(t.read_bytes()).hexdigest() + ' delivered_revision_unchanged=true')
PY
