#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Start from immutable original predictions; change only 134 priority arrays."""
import copy
import csv
import difflib
import hashlib
import json
from pathlib import Path

D = Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    raw = (D / 'original/prediction.jsonl').read_bytes()
    v2 = (D / 'original/REFERENCE_V2_prediction.jsonl').read_bytes()
    assert sha(raw) == '72929a96f039d40ec442f5d656c061817c5ac9ab485dd3f06326746626711232'
    assert sha(v2) == '00c90605e2004afe176349208e725e45f83ec306390bf562570b78ab508537e8'
    original = [json.loads(x) for x in raw.splitlines()]
    prior = {x['sample_id']: x for x in map(json.loads, v2.splitlines())}
    inputs = {x['sample_id']: x for x in map(json.loads, (D / 'official/inputs.jsonl').read_text().splitlines())}
    labels = json.loads((D / 'official/labels.json').read_text())
    warnings = list(csv.DictReader((D / 'original/OFFICIAL_WARNINGS_144.csv').open(encoding='utf-8-sig')))
    sort_warnings = {w['sample_id']: w['official_warning'] for w in warnings if 'priority_order 未按紧迫度序列排序' in w['official_warning']}
    responsibility_warnings = {w['sample_id']: w['official_warning'] for w in warnings if 'organized_infringement=' in w['official_warning']}
    assert len(warnings) == 144 and len(sort_warnings) == 134 and len(responsibility_warnings) == 10
    assert not set(sort_warnings) & set(responsibility_warnings)
    output, changes, restored = [], [], []
    base = labels['disposal_urgency_order']
    mod = labels['disposal_urgency_modifier']
    for old, line in zip(original, raw.splitlines(keepends=True)):
        sid = old['sample_id']
        new = copy.deepcopy(old)
        if sid in sort_warnings:
            c = new['prediction']['task_C']
            before = c['priority_order'][:]
            after = sorted(before, key=base.index)
            level = inputs[sid]['context'][mod['field']]
            if level == mod['trigger']:
                after = [m for m in after if m in mod['promote']] + [m for m in after if m not in mod['promote']]
            assert before != after and set(before) == set(after) == set(c['disposal_measures'])
            c['priority_order'] = after
            assert new == prior[sid], 'preserved sorting differs from accepted v2: ' + sid
            output.append((json.dumps(new, ensure_ascii=False, separators=(',', ':')) + '\n').encode())
            changes.append({'sample_id': sid, 'field': 'prediction.task_C.priority_order', 'before': before, 'after': after, 'propagation_level': level, 'original_warning': sort_warnings[sid], 'reason': '仅按官方基础紧迫度及爆档M03提权规则排序；措施集合不变。'})
        else:
            output.append(line)
        if sid in responsibility_warnings:
            before_b = prior[sid]['prediction']['task_B']
            original_b = old['prediction']['task_B']
            fields = [k for k in original_b if before_b[k] != original_b[k]]
            assert len(fields) == 1
            restored.append({'sample_id': sid, 'restored_field': 'prediction.task_B.' + fields[0], 'previous_v2_value': before_b[fields[0]], 'restored_original_value': original_b[fields[0]], 'original_task_B': original_b, 'v3_task_B': new['prediction']['task_B'], 'full_input': inputs[sid], 'official_warning_retained': responsibility_warnings[sid], 'status': '已恢复原版；实体判断待复核；不为消WARN改判'})
    revised = b''.join(output)
    assert len(changes) == 134 and len(restored) == 10
    (D / 'MODIFIED_FILE.jsonl').write_bytes(revised)
    (D / 'prediction.jsonl').write_bytes(revised)
    (D / 'CHANGES_134.jsonl').write_text(''.join(json.dumps(x, ensure_ascii=False) + '\n' for x in changes), encoding='utf-8')
    (D / 'RESPONSIBILITY_RESTORED_10.json').write_text(json.dumps(restored, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    (D / 'DIFF_FILE.patch').write_text(''.join(difflib.unified_diff(raw.decode().splitlines(keepends=True), revised.decode().splitlines(keepends=True), fromfile='original/prediction.jsonl', tofile='MODIFIED_FILE.jsonl', n=1)), encoding='utf-8')
    (D / 'RESTORE_FROM_V2.patch').write_text(''.join(difflib.unified_diff(v2.decode().splitlines(keepends=True), revised.decode().splitlines(keepends=True), fromfile='original/REFERENCE_V2_prediction.jsonl', tofile='MODIFIED_FILE.jsonl', n=1)), encoding='utf-8')
    summary = {'version': 'v3_sortonly', 'status': 'BUILT_PENDING_VERIFICATION', 'rows': 2100, 'changed_rows_vs_original': 134, 'changed_fields_vs_original': 134, 'changed_field_only': 'prediction.task_C.priority_order', 'unchanged_rows_vs_original_byte_exact': 1966, 'task_B_original_exact_rows': 2100, 'responsibility_cases_restored_from_v2': 10, 'sorted_cases_match_v2': 134, 'original_sha256': sha(raw), 'reference_v2_sha256': sha(v2), 'modified_sha256': sha(revised), 'expected_official_ERROR': 0, 'expected_official_WARN': 10, 'WARN_policy': '保留并单独列出原版责任一致性WARN；不做实体改判', 'native_responses_edited': False, 'model_rerun': False, 'uploaded': False}
    (D / 'SUMMARY.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('BUILD PASS rows=2100 priority_only=134 responsibility_restored=10 task_B_original_exact=2100')


if __name__ == '__main__':
    main()
