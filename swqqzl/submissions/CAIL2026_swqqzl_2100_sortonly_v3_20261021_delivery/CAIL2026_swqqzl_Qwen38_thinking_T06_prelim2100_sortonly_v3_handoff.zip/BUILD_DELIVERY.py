#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Package v3 sorting-only outputs, preserving the ten original responsibility warnings."""
import hashlib
import json
import os
import shlex
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

D = Path(__file__).resolve().parent
PREFIX = 'CAIL2026_swqqzl_Qwen38_thinking_T06_prelim2100_sortonly_v3'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    assert json.loads(path.read_text()) == obj


def zverify(path):
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        names = z.namelist()
        assert len(names) == len(set(names))
        assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in names)
        return {'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes()), 'members': len(names), 'CRC': 'PASS'}


def main():
    revised = (D / 'MODIFIED_FILE.jsonl').read_bytes()
    rebuild = subprocess.run([sys.executable, str(D / 'MAKE_SORTONLY.py')], capture_output=True, text=True)
    assert rebuild.returncode == 0 and (D / 'MODIFIED_FILE.jsonl').read_bytes() == revised
    transactions = []
    for stage in ('baseline', 'previous_v2', 'modified', 'rollback'):
        cmd = [sys.executable, str(D / 'VERIFY_SORTONLY.py'), stage]
        r = subprocess.run(cmd, capture_output=True, text=True)
        assert r.returncode == 0, r.stdout + r.stderr
        report = json.loads((D / 'checks' / (stage.upper() + '.json')).read_text())
        assert r.stdout == report['literal_result'] + '\n'
        transactions.append({'stage': stage.upper(), 'command': cmd, 'input': report['input_path'], 'literal_stdout': r.stdout, 'literal_stderr': r.stderr, 'exit_status': r.returncode, 'official_command': report['official']['command'], 'official_exit_status': report['official']['exit_status'], 'official_ERROR': report['official']['ERROR'], 'official_WARN': report['official']['WARN']})
    save(D / 'checks/TRANSACTIONS.json', transactions)
    summary = json.loads((D / 'SUMMARY.json').read_text())
    check = json.loads((D / 'checks/MODIFIED.json').read_text())
    assert check['official']['WARN'] == 10 and check['entire_task_B_original_exact_rows'] == 2100
    summary.update({'status': 'VERIFIED_WITH_10_RETAINED_ORIGINAL_WARNINGS', 'official_ERROR': 0, 'official_WARN': 10, 'remaining_sort_warnings': 0, 'remaining_responsibility_warnings': 10, 'rollback_test': 'PASS_ON_SEPARATE_COPY', 'original_final_native_responses_preserved': 2100, 'original_native_thinking_nonempty': 2100, 'original_native_finish_stop': 2100, 'v3_rows_still_native_equal': 1966})
    save(D / 'SUMMARY.json', summary)
    text = [
        'CAIL2026 涉网侵权治理2100条 v3：仅保留134条排序修正，责任判断全部恢复原版',
        'Checked at: ' + datetime.now(timezone.utc).isoformat(),
        'Changed field vs original: prediction.task_C.priority_order, exactly 134 rows/134 fields.',
        'Restored from v2: prediction.task_B.organized_infringement true->false on 8 rows; prediction.task_B.organizer_liability joint->不承担责任 on 2 rows.',
        'All 2100 task_B blocks, task_A blocks, citations and disposal_measures exactly equal the original. The ten responsibility rows equal the complete original rows byte-for-byte.',
        'Official checker: ERROR=0 WARN=10; zero sorting warnings; the ten responsibility warnings match the original warnings verbatim. They are retained, not suppressed or converted into new answers.',
        'Original predictions SHA256: ' + summary['original_sha256'],
        'Reference v2 predictions SHA256: ' + summary['reference_v2_sha256'],
        'Modified v3 predictions SHA256: ' + summary['modified_sha256'],
        'MODIFIED_FILE: ' + str(D / 'MODIFIED_FILE.jsonl'),
        'DIFF_FILE: ' + str(D / 'DIFF_FILE.patch'),
        'VERIFICATION: ' + str(D / 'VERIFICATION.txt'),
        'ROLLBACK: ' + str(D / 'ROLLBACK.sh'),
        '',
    ]
    for t in transactions:
        text += [t['stage'], 'Exact command: ' + shlex.join(t['command']), 'Input: ' + t['input'], 'Literal stdout:', t['literal_stdout'].rstrip('\n'), 'Literal stderr: ' + repr(t['literal_stderr']), 'Exit status: ' + str(t['exit_status']), 'Official exact command: ' + shlex.join(t['official_command']), 'Official exit status: ' + str(t['official_exit_status']), 'Official literal stdout:', (D / 'checks' / (t['stage'] + '_OFFICIAL.txt')).read_text().rstrip('\n'), '']
    rollback = json.loads((D / 'checks/ROLLBACK.json').read_text())['rollback']
    text += [
        'Rollback script exact command: ' + shlex.join(rollback['command']),
        'Rollback literal stdout: ' + rollback['literal_stdout'].rstrip('\n'),
        'Rollback exit status: ' + str(rollback['exit_status']),
        'Restored behavior/status: independent rollback_test/prediction.jsonl restored to original SHA256 and ERROR=0 WARN=144 exit=0. Delivered MODIFIED_FILE.jsonl and prediction.jsonl stay v3, ERROR=0 WARN=10.',
        'Native provenance: original archive unchanged; 2100 original outputs match native final JSON; 2100 nonempty thinking; 2100 finish_reason=stop. Revised/native exact match rows=1966; the other 134 differ only in priority_order.',
        '134 sorted rows match v2 exactly; v3 differs from v2 only on the ten reviewed responsibility fields.',
        'Prior original/v2/review artifacts rehashed unchanged: ' + str(check['prior_original_v2_review_files_unchanged']) + '/' + str(check['prior_files_manifest_count']),
        'Negative control: responsibility-field edit is outside the permitted sorting-only scope and is rejected.',
        'No model rerun, prompt/generation change, competition upload or automation restart occurred.',
    ]
    (D / 'VERIFICATION.txt').write_text('\n'.join(text) + '\n', encoding='utf-8')
    readme = '''CAIL2026 涉网侵权治理初赛2100条 — v3仅排序修正版

本版按用户要求，只保留134条确定性排序修正，撤回v2中的全部10条责任判断修改。
官方checker结果：0 ERROR、10 WARN；10条均为原版责任字段一致性警告，已单独列出并原样保留，不代表新增实体判断。

一、修改边界
从不可变的原始2100条预测重建，只调整134条 prediction.task_C.priority_order。
基础紧迫度及传播档位“爆”时的M03提权均按官方labels.json执行；措施集合不增删。
全部2100条的task_B、task_A、citations及disposal_measures均与原版完全一致。
10条责任案例整行恢复原版，字节级相同。其余排序修改与v2一致。
相对原版仅134行/134字段不同，1966行字节级不变。

二、优先使用哪些文件
''' + PREFIX + '''_submission.zip：新版提交包，唯一成员prediction.jsonl，完整2100条。
prediction.jsonl / MODIFIED_FILE.jsonl：同一份新版完整结果。
OFFICIAL_WARNINGS_10.txt / .csv / .json：剩余10条WARN，包含原始checker文字；CSV含保留原因。
RESPONSIBILITY_RESTORED_10.json：10条从v2恢复到原版的具体字段、值、完整B及案件输入。
CHANGES_134.jsonl / DIFF_FILE.patch：相对原版仅134条排序改动的逐项记录和差异。
RESTORE_FROM_V2.patch：相对v2撤回10条责任修改的差异。
VERIFICATION.txt / checks：原版、v2参照、新版、独立副本回滚的命令、输入、逐字输出及退出状态。

三、原版和原始响应
original/prediction.jsonl：原版2100条，不修改。
original/REFERENCE_V2_prediction.jsonl：仅供对照的v2，不是本次提交文件。
original/ORIGINAL_SUBMISSION.zip：原始提交ZIP，仅供留档。
original/ORIGINAL_HANDOFF.zip：原始完整交接包，含2100条原生输出、thinking、请求、提示词、输入和历史失败记录，字节不变。
原版、v2及上轮责任审查目录仍在原位置保留，SHA256清单见original/ORIGINAL_FILES_SHA256.json。

四、剩余WARN
8条是 organized_infringement=false 但原organizer_liability非“不承担责任”；
2条是 organized_infringement=true 但原organizer_liability为“不承担责任”。
本版不决定这10条谁承担何种责任，也不证明原答案正确；只按用户要求恢复原判并保留警告，等待实体复核。
官方checker未改字节，完整执行；没有过滤或压制警告。

五、复验
在本目录执行 python3 VERIFY_SORTONLY.py baseline / modified / rollback。
预期依次为0 ERROR/144 WARN、0 ERROR/10 WARN、回滚副本0 ERROR/144 WARN；退出状态均为0。
ROLLBACK.sh仅允许修改rollback_test/下的独立副本，拒绝覆盖新版交付结果。

六、运行与原生性
模型仍是原运行的Qwen/Qwen3.8-27B，thinking=true、reasoning_effort=medium、temperature=0.6。
本次没有重跑模型，未改提示词、生成预算和原始响应，未上传比赛，未重启定时任务。
原2100条都与原生最终JSON相等、thinking非空、finish_reason=stop。
v3是确定性排序后处理结果：1966条仍等于原生输出，134条仅优先级数组不同。
校验通过是数据/格式/修改范围通过，不是官方准确率或比赛评分。
'''
    (D / 'README_交付说明.txt').write_text(readme, encoding='utf-8')
    sub = D / (PREFIX + '_submission.zip')
    with zipfile.ZipFile(sub, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr('prediction.jsonl', revised)
    sub_info = zverify(sub)
    with zipfile.ZipFile(sub) as z:
        assert z.namelist() == ['prediction.jsonl'] and z.read('prediction.jsonl') == revised
    assert os.access(D / 'ROLLBACK.sh', os.X_OK)
    excluded = {'CONTENT_MANIFEST.json', 'PACKAGE_MANIFEST.json', 'SHA256SUMS.txt', 'FINAL_DELIVERY_CHECK.json', 'ARCHIVE_REOPEN_CHECK.json'}
    files = [p for p in D.rglob('*') if p.is_file() and '__pycache__' not in p.parts and 'rollback_test' not in p.parts and p.name not in excluded and not p.name.endswith('_handoff.zip')]
    content_manifest = {str(p.relative_to(D)): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in sorted(files)}
    save(D / 'CONTENT_MANIFEST.json', content_manifest)
    files.append(D / 'CONTENT_MANIFEST.json')
    handoff = D / (PREFIX + '_handoff.zip')
    with zipfile.ZipFile(handoff, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(files):
            z.write(p, str(p.relative_to(D)), compress_type=zipfile.ZIP_STORED if p.suffix == '.zip' else zipfile.ZIP_DEFLATED)
    handoff_info = zverify(handoff)
    with zipfile.ZipFile(handoff) as z:
        assert z.read('prediction.jsonl') == z.read('MODIFIED_FILE.jsonl') == revised
        assert z.read(sub.name) == sub.read_bytes()
        assert z.getinfo('ROLLBACK.sh').external_attr >> 16 & 0o111
        for n, m in content_manifest.items():
            b = z.read(n)
            assert len(b) == m['bytes'] and sha(b) == m['sha256']
    packages = {sub.name: sub_info, handoff.name: handoff_info}
    save(D / 'PACKAGE_MANIFEST.json', packages)
    (D / 'SHA256SUMS.txt').write_text(''.join(m['sha256'] + '  ' + n + '\n' for n, m in packages.items()) + sha(revised) + '  prediction.jsonl\n', encoding='utf-8')
    outer = D.parent / 'CAIL2026_swqqzl_2100_sortonly_v3_20261021_delivery.zip'
    names = [sub.name, handoff.name, 'prediction.jsonl', 'README_交付说明.txt', 'VERIFICATION.txt', 'OFFICIAL_WARNINGS_10.txt', 'OFFICIAL_WARNINGS_10.csv', 'OFFICIAL_WARNINGS_10.json', 'RESPONSIBILITY_RESTORED_10.json', 'CHANGES_134.jsonl', 'DIFF_FILE.patch', 'RESTORE_FROM_V2.patch', 'SUMMARY.json', 'PACKAGE_MANIFEST.json', 'SHA256SUMS.txt']
    with zipfile.ZipFile(outer, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for n in names:
            z.write(D / n, n, compress_type=zipfile.ZIP_STORED if n.endswith('.zip') else zipfile.ZIP_DEFLATED)
    outer_info = zverify(outer)
    with zipfile.ZipFile(outer) as z:
        assert z.namelist() == names
        for n in names:
            assert z.read(n) == (D / n).read_bytes()
    Path(str(outer) + '.sha256').write_text(outer_info['sha256'] + '  ' + outer.name + '\n', encoding='utf-8')
    # Reopen every claimed transaction artifact and retained warning list.
    assert (D / 'MODIFIED_FILE.jsonl').read_bytes() == revised
    assert (D / 'DIFF_FILE.patch').read_text().startswith('--- original/prediction.jsonl\n+++ MODIFIED_FILE.jsonl\n')
    assert 'WARN=10' in (D / 'VERIFICATION.txt').read_text()
    assert (D / 'ROLLBACK.sh').read_text().startswith('#!/bin/sh\n') and os.access(D / 'ROLLBACK.sh', os.X_OK)
    assert len(json.loads((D / 'OFFICIAL_WARNINGS_10.json').read_text())) == 10
    for p, m in json.loads((D / 'original/ORIGINAL_FILES_SHA256.json').read_text()).items():
        assert sha(Path(p).read_bytes()) == m['sha256'], p
    final = {'status': 'PASS_WITH_10_RETAINED_ORIGINAL_WARNINGS', 'rows': 2100, 'changed_rows_vs_original': 134, 'changed_field_only': 'prediction.task_C.priority_order', 'task_B_original_exact_rows': 2100, 'responsibility_cases_restored': 10, 'official_ERROR': 0, 'official_WARN': 10, 'sorting_WARN': 0, 'responsibility_WARN': 10, 'submission_single_member': 'prediction.jsonl', 'source_files_preserved': check['prior_original_v2_review_files_unchanged'], 'ZIP_CRC_SHA256_and_member_bytes': 'PASS', 'transaction_artifacts_reopened': True, 'rollback_copy_test': 'PASS', 'model_rerun': False, 'uploaded': False, 'packages': packages, 'outer_delivery': dict(outer_info, path=str(outer))}
    save(D / 'FINAL_DELIVERY_CHECK.json', final)
    print(json.dumps(final, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
